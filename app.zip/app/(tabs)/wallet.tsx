import Screen from './wallets/paymentmethod';
export default Screen;
