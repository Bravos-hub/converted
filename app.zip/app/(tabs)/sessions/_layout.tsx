import { Stack } from 'expo-router';
import React from 'react';

export default function SessionsStackLayout() {
  return <Stack screenOptions={{ headerShown: false }} />;
}

