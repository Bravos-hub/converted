import { Stack } from 'expo-router';
import React from 'react';

export default function WalletsStackLayout() {
  return <Stack screenOptions={{ headerShown: false }} />;
}

